var i = 4;
if(i==0){
    console.log("ноль");
}

else if(i==1){
    console.log("один");
}
else if(i==2){
    console.log("два");
}
else if(i==3){
    console.log("три");
}
else if(i==4){
    console.log("четыре");
}
else if(i==5){
    console.log("пять");
}
else if(i==6){
    console.log("шесть");
}
else if(i==7){
    console.log("семь");
}
else if(i==8){
    console.log("восемь");
}
else if(i==9){
    console.log("девять");
}


var a = 12;
if(a == 0){
    console.log("Число равно 0");
}
else if(a >= 0){
    console.log("Число положительное");
}
else if(a <= 0){
    console.log("Число отрицательное");
}


var b = "MB";
var c = 12;
var result = 0;
if (b == "Byte"){
    console.log( result = c )
}
else if(b == "KB"){
    console.log( result = c * 1024)
}
else if(b == "MB"){
    console.log( result = c * 1048576)
}
else if(b == "GB"){
    console.log( result = c * 1073741824)
}



var p = 20;
var s = 20000;
var y = 4;
var percentalltime = 100 + p; //Процент за всё время
console.log(percentalltime);
var percentoneyear = p / y; // Процент за 1 год
console.log(percentoneyear);
var sum = s + ( (s * p) / 100); // Вся сумма которую вернёт клиент банку
console.log(sum);

